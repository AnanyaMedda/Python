def find_smallest_number(arr):
    return min(arr)

# Example usage
arr = [10, 5, 7, 3, 9]
print("Smallest number in the array:", find_smallest_number(arr))

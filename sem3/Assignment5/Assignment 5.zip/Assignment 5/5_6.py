# Option 1 : Creating a dictionary with {} and :
dog = {"name" : "", "color" : "", "legs" : "", "breed" : "", "age" : ""}

# Option 2 : Creating a dictionary with dict() constructor
dog = dict(name = "", color = "", legs = "", breed = "", age = "")
print(dict)
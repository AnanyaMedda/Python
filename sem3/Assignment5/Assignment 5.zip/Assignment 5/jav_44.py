def find_range(arr):
    return max(arr) - min(arr)

# Example usage
arr = [3, 5, 7, 2, 8, -1, 4]
print("Range of the array:", find_range(arr))

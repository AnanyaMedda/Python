fruits = ['Python', 'Numpy','Pandas','Django', 'Flask']

# Option 1 : using For loop with range
for i in range(0,len(fruits)):
    print (fruits[i])

# Option 2 : Using For..In loop
for i in fruits:
    print(i)

# Option 3 : Using Slicing
print(fruits[:])

# Option 4 : Using list name
print(fruits)